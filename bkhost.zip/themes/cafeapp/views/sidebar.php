<div class="app_sidebar_nav">
<!--    <a class="icon-home radius transition" title="Dashboard" href="--><?//= url("/app"); ?><!--">Controle</a>-->
<!--    <a class="icon-briefcase radius transition " title="Carteiras" href="--><?//= url("/app/carteiras"); ?><!--">Carteiras</a>-->
<!--    <a class="icon-calendar-check-o radius transition" title="Receber" href="--><?//= url("/app/receber"); ?><!--">Receber</a>-->
<!--    <a class="icon-calendar-minus-o radius transition " title="Pagar" href="--><?//= url("/app/pagar"); ?><!--">Pagar</a>-->
<!--    <a class="icon-exchange radius transition " title="Fixas" href="--><?//= url("/app/fixas"); ?><!--">Fixas</a>-->
    <a class="icon-user radius transition" title="Perfil" href="<?= url("/app/perfil"); ?>">Perfil</a>
<!--    <a class="icon-coffee radius transition" title="Assinatura" href="--><?//= url("/app/assinatura"); ?><!--">Assinatura</a>-->
    <span class="icon-life-ring radius transition" data-modalopen=".app_modal_contact">Suporte</span>
    <a class="icon-sign-out radius transition" title="Sair" href="<?= url("/app/sair"); ?>">Sair</a>
</div>